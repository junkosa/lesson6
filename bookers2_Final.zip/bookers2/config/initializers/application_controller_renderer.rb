# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end
Refile.secret_key = 'f67039853d8ecd592ae6f916325eaa8a3fae05ced0d1d565e62619685e87ffc8bfb080e035e930ae505c8d1856d08508b20c41f44bb0f7ae226b553ff4e43462'